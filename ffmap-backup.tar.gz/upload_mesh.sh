#!/bin/bash

HOST="af991.netcup.net"
USER="hosting102099"
PASS="kalisto334"

LOCAL_DIR="/home/marcus/ffmap/yanic/data"
REMOTE_DIR="/freifunk/json"

lftp -u "$USER","$PASS" $HOST <<EOF
set ftp:ssl-allow yes
set ssl:verify-certificate no
cd $REMOTE_DIR
mirror -R --delete --verbose $LOCAL_DIR .
quit
EOF
